//
//  RequirementViewController.swift
//  NavyApp
//
//  Created by Rafael Amaro on 11/20/20.
//

import UIKit

class RequirementViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Requirements"
    }
}
